import java.awt.Graphics;

public abstract class DrawMode {
	
	public abstract void DrawFigure(SimplePainterModel data, Graphics nPage);
}
